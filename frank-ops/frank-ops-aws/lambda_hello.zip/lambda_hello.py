def handler(event, context):
    return {
        "correlationID": event["correlationID"],
        "message": event["message"]
    }
